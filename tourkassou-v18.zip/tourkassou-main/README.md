# Soukassou Pro v18

PWA hors-ligne de gestion commerciale : caisse, stock, clients/crédits, contrats PDF signés, rapports, sauvegarde JSON, FR/AR.

Publication GitHub Pages : `git add . && git commit -m "v18" && git push origin main`

Le code Admin se définit à la première utilisation (stocké haché sur l'appareil). Aucun secret ne doit être mis dans ce dépôt.
