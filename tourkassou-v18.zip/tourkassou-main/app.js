'use strict';
const $ = s => document.querySelector(s);
const fmt = n => String(Math.round(+n || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' FCFA';
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const LOCK_MS = 120000;
const card = 'bg-slate-800 border border-slate-700 rounded-2xl p-3';
const inp = 'w-full bg-slate-900 border border-slate-600 rounded-xl p-2 text-sm';
const btn = 'bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl py-2 px-3 font-medium';

const L = {
  fr: {caisse:'Caisse',clients:'Clients',stock:'Stock',rapports:'Rapports',total:'Total',pay:'Encaisser',cash:'Espèces',mm:'Mobile Money',credit:'Crédit',add:'Ajouter',name:'Nom',price:'Prix',qty:'Quantité',phone:'Téléphone',paid:'Payé',contract:'Contrat',today:'Ventes du jour',debts:'Dettes',low:'Stock bas (≤2)',export:'Exporter',import:'Importer',empty:'Aucun produit',ref:'Réf. transaction Mobile Money',cart:'Panier',score:'Score'},
  ar: {caisse:'الصندوق',clients:'العملاء',stock:'المخزون',rapports:'التقارير',total:'المجموع',pay:'تحصيل',cash:'نقداً',mm:'المال المحمول',credit:'آجل',add:'إضافة',name:'الاسم',price:'السعر',qty:'الكمية',phone:'الهاتف',paid:'مدفوع',contract:'عقد',today:'مبيعات اليوم',debts:'الديون',low:'مخزون منخفض',export:'تصدير',import:'استيراد',empty:'لا منتجات',ref:'مرجع العملية',cart:'السلة',score:'التقييم'}
};
let lang = localStorage.lang || 'fr', tab = 'caisse', cart = [];
const t = k => L[lang][k] || k;

// ---------- Base de données locale (IndexedDB) ----------
const DB = (() => {
  let db;
  const open = () => new Promise((ok, ko) => {
    const r = indexedDB.open('soukassou', 1);
    r.onupgradeneeded = () => ['produits','clients','ventes'].forEach(s => r.result.createObjectStore(s, {keyPath:'id', autoIncrement:true}));
    r.onsuccess = () => { db = r.result; ok(); };
    r.onerror = () => ko(r.error);
  });
  const tx = (s, m, f) => new Promise((ok, ko) => {
    const x = db.transaction(s, m), q = f(x.objectStore(s));
    x.oncomplete = () => ok(q && q.result); x.onerror = () => ko(x.error);
  });
  return {open, all: s => tx(s,'readonly',o=>o.getAll()), put: (s,v) => tx(s,'readwrite',o=>o.put(v)),
          del: (s,id) => tx(s,'readwrite',o=>o.delete(id)), clear: s => tx(s,'readwrite',o=>o.clear())};
})();

// ---------- Vues ----------
const views = {
  caisse: (P, C) => {
    const tot = cart.reduce((s,l) => s + l.prix*l.q, 0);
    return `<div class="grid grid-cols-2 gap-2">${P.map(p => `<button onclick="addCart(${p.id})" class="${card} text-left"><b>${esc(p.nom)}</b><br><span class="text-xs text-slate-400">${fmt(p.prix)} · ${p.stock}</span></button>`).join('') || `<p class="text-slate-500 col-span-2">${t('empty')} → ${t('stock')}</p>`}</div>
    <div class="${card} space-y-2"><b>${t('cart')}</b>
    ${cart.map((l,i) => `<div class="flex justify-between text-sm"><span>${esc(l.nom)} ×${l.q}</span><button onclick="cart.splice(${i},1);render()" class="text-rose-400">✕</button></div>`).join('')}
    <div class="text-lg font-bold">${t('total')} : ${fmt(tot)}</div>
    <select id="mode" class="${inp}"><option value="cash">${t('cash')}</option><option value="mm">${t('mm')}</option><option value="credit">${t('credit')}</option></select>
    <select id="cli" class="${inp}"><option value="">— ${t('clients')} —</option>${C.map(c => `<option value="${c.id}">${esc(c.nom)}</option>`).join('')}</select>
    <input id="ref" class="${inp}" placeholder="${t('ref')}">
    <button onclick="checkout()" class="${btn} w-full">${t('pay')}</button></div>`;
  },
  stock: P => `<div class="${card} space-y-2"><input id="pn" class="${inp}" placeholder="${t('name')}"><input id="pp" type="number" min="0" class="${inp}" placeholder="${t('price')}"><input id="ps" type="number" min="0" class="${inp}" placeholder="${t('qty')}"><button onclick="addProd()" class="${btn} w-full">${t('add')}</button></div>`
    + P.map(p => `<div class="${card} flex justify-between items-center"><span>${esc(p.nom)}<br><small class="text-slate-400">${fmt(p.prix)} · ${p.stock}</small></span><span class="space-x-3"><button onclick="restock(${p.id})">＋</button><button onclick="del('produits',${p.id})">🗑</button></span></div>`).join(''),
  clients: (P, C, V) => `<div class="${card} space-y-2"><input id="cn" class="${inp}" placeholder="${t('name')}"><input id="ct" class="${inp}" placeholder="${t('phone')}"><button onclick="addCli()" class="${btn} w-full">${t('add')}</button></div>`
    + C.map(c => {
      const cs = V.filter(v => v.cid == c.id && v.mode == 'credit'), du = cs.filter(v => !v.paye);
      const sc = cs.length ? Math.round(1000 * (cs.length - du.length) / cs.length) : '—';
      return `<div class="${card} space-y-1"><div class="flex justify-between"><b>${esc(c.nom)}</b><span class="text-xs text-amber-400">${t('score')} ${sc}</span></div>
      <div class="text-xs text-slate-400">${esc(c.tel)}</div><div class="text-sm">${t('debts')} : ${fmt(du.reduce((s,v) => s+v.total, 0))}</div>
      ${du.map(v => `<button onclick="payer(${v.id})" class="text-xs bg-slate-700 rounded-lg px-2 py-1 mr-1">${fmt(v.total)} → ${t('paid')}</button>`).join('')}
      <div><button onclick="contrat(${c.id})" class="${btn} text-xs">${t('contract')}</button> <button onclick="del('clients',${c.id})" class="text-rose-400 text-xs ml-2">🗑</button></div></div>`;
    }).join(''),
  rapports: (P, V) => {
    const d0 = new Date().setHours(0,0,0,0), j = V.filter(v => v.date >= d0), s = a => a.reduce((n,v) => n+v.total, 0);
    return `<div class="grid grid-cols-2 gap-2"><div class="${card}"><small>${t('today')}</small><div class="font-bold">${fmt(s(j))}</div><small>${j.length}</small></div>
    <div class="${card}"><small>${t('debts')}</small><div class="font-bold text-amber-400">${fmt(s(V.filter(v => !v.paye)))}</div></div></div>
    <div class="${card}"><b>${t('low')}</b>${P.filter(p => p.stock <= 2).map(p => `<div class="text-sm">${esc(p.nom)} : ${p.stock}</div>`).join('') || '<div class="text-sm text-slate-500">—</div>'}</div>
    <div class="${card} flex gap-2"><button onclick="exportData()" class="${btn} flex-1">${t('export')}</button><label class="${btn} flex-1 text-center cursor-pointer">${t('import')}<input type="file" accept=".json" hidden onchange="importData(event)"></label></div>`;
  }
};

async function render() {
  document.documentElement.dir = lang == 'ar' ? 'rtl' : 'ltr';
  $('#nav').innerHTML = ['caisse','clients','stock','rapports'].map(k => `<button onclick="go('${k}')" class="flex-1 py-3 text-sm ${tab==k ? 'text-emerald-400 font-bold' : 'text-slate-400'}">${t(k)}</button>`).join('');
  const [P, C, V] = await Promise.all([DB.all('produits'), DB.all('clients'), DB.all('ventes')]);
  $('#view').innerHTML = tab == 'rapports' ? views.rapports(P, V) : views[tab](P, C, V);
}
const go = k => { tab = k; render(); };
const toggleLang = () => { lang = lang == 'fr' ? 'ar' : 'fr'; localStorage.lang = lang; render(); };

// ---------- Actions ----------
const getP = async id => (await DB.all('produits')).find(x => x.id == id);
async function addProd() {
  const nom = $('#pn').value.trim(), prix = +$('#pp').value, stock = +$('#ps').value;
  if (!nom || !(prix >= 0) || !(stock >= 0)) return alert('Nom, prix et quantité valides requis.');
  await DB.put('produits', {nom, prix, stock}); render();
}
async function addCli() {
  const nom = $('#cn').value.trim(); if (!nom) return;
  await DB.put('clients', {nom, tel: $('#ct').value.trim()}); render();
}
async function restock(id) {
  const n = parseInt(prompt('Quantité à ajouter :'), 10); if (!n) return;
  const p = await getP(id); p.stock += n; await DB.put('produits', p); render();
}
async function del(s, id) { if (confirm('Supprimer ?')) { await DB.del(s, id); render(); } }
async function addCart(id) {
  const p = await getP(id), l = cart.find(x => x.id == id);
  if ((l ? l.q : 0) >= p.stock) return alert('Stock insuffisant.');
  l ? l.q++ : cart.push({id: p.id, nom: p.nom, prix: p.prix, q: 1}); render();
}
async function checkout() {
  if (!cart.length) return;
  const mode = $('#mode').value, cid = +$('#cli').value || null, ref = $('#ref').value.trim();
  if (mode == 'credit' && !cid) return alert('Choisissez un client pour une vente à crédit.');
  const v = {date: Date.now(), lignes: cart, total: cart.reduce((s,l) => s + l.prix*l.q, 0), mode, cid, ref, paye: mode != 'credit'};
  v.id = await DB.put('ventes', v);
  for (const l of cart) { const p = await getP(l.id); if (p) { p.stock -= l.q; await DB.put('produits', p); } }
  receipt(v); cart = []; render();
}
async function payer(id) {
  const v = (await DB.all('ventes')).find(x => x.id == id); v.paye = true; await DB.put('ventes', v); render();
}

// ---------- PDF : reçu et contrat signé ----------
function receipt(v) {
  const d = new window.jspdf.jsPDF({format: [80, 50 + v.lignes.length * 7]}); let y = 10;
  d.setFontSize(11); d.text('SOUKASSOU PRO', 40, y, {align:'center'}); y += 6;
  d.setFontSize(8); d.text(new Date(v.date).toLocaleString('fr-FR'), 40, y, {align:'center'}); y += 7;
  v.lignes.forEach(l => { d.text(`${l.nom} x${l.q}`, 5, y); d.text(fmt(l.prix * l.q), 75, y, {align:'right'}); y += 6; });
  d.setFontSize(10); d.text('TOTAL ' + fmt(v.total), 5, y + 3);
  d.setFontSize(8); d.text(`Paiement : ${v.mode}${v.ref ? ' / ' + v.ref : ''}${v.paye ? '' : ' (A PAYER)'}`, 5, y + 9);
  d.save(`Recu_${v.id}.pdf`);
}
let sigCid = null;
function contrat(cid) { sigCid = cid; clearSig(); $('#modal').classList.remove('hidden'); }
function clearSig() { const c = $('#sig'); c.getContext('2d').clearRect(0, 0, c.width, c.height); }
(() => {
  const c = $('#sig'), x = c.getContext('2d'); let d = false;
  x.lineWidth = 3; x.lineCap = 'round'; x.strokeStyle = '#000';
  const p = e => { const r = c.getBoundingClientRect(); return [(e.clientX - r.left) * c.width / r.width, (e.clientY - r.top) * c.height / r.height]; };
  c.onpointerdown = e => { d = true; x.beginPath(); x.moveTo(...p(e)); };
  c.onpointermove = e => { if (d) { x.lineTo(...p(e)); x.stroke(); } };
  c.onpointerup = c.onpointerleave = () => d = false;
})();
async function saveContrat() {
  const cl = (await DB.all('clients')).find(x => x.id == sigCid), V = await DB.all('ventes');
  const m = V.filter(v => v.cid == sigCid && !v.paye).reduce((s,v) => s + v.total, 0);
  const d = new window.jspdf.jsPDF();
  d.setFontSize(14); d.text('CONTRAT DE VENTE A TEMPERAMENT', 105, 20, {align:'center'});
  d.setFontSize(11);
  d.text('Date : ' + new Date().toLocaleDateString('fr-FR'), 20, 40);
  d.text(`Client : ${cl.nom}   Tel : ${cl.tel || '-'}`, 20, 50);
  d.text('Montant restant dû : ' + fmt(m), 20, 60);
  d.text("Le client reconnaît devoir la somme ci-dessus à Soukassou Pro", 20, 75);
  d.text("et s'engage à la régler selon l'échéancier convenu.", 20, 82);
  d.text('Signature du client :', 20, 105);
  d.addImage($('#sig').toDataURL('image/png'), 'PNG', 20, 110, 80, 40);
  d.save(`Contrat_${cl.nom}.pdf`); $('#modal').classList.add('hidden');
}

// ---------- Sauvegarde / restauration ----------
async function exportData() {
  const o = {v: 1, produits: await DB.all('produits'), clients: await DB.all('clients'), ventes: await DB.all('ventes')};
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([JSON.stringify(o)], {type:'application/json'}));
  a.download = `soukassou_${new Date().toISOString().slice(0,10)}.json`; a.click();
}
async function importData(e) {
  const f = e.target.files[0]; if (!f || !confirm('Remplacer TOUTES les données actuelles ?')) return;
  try {
    const o = JSON.parse(await f.text());
    for (const s of ['produits','clients','ventes']) if (!Array.isArray(o[s])) throw 0;
    for (const s of ['produits','clients','ventes']) { await DB.clear(s); for (const r of o[s]) await DB.put(s, r); }
    render();
  } catch { alert('Fichier de sauvegarde invalide.'); }
}

// ---------- Verrouillage (code haché + inactivité) ----------
async function sha(s) {
  const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
}
async function lock() {
  if (!localStorage.soukassou_pin_hash) {
    const p = prompt('Choisissez votre code Admin (6 caractères minimum) :');
    if (!p || p.length < 6) return;
    const s = crypto.randomUUID();
    localStorage.soukassou_pin_salt = s; localStorage.soukassou_pin_hash = await sha(s + p);
    return alert('Code enregistré. Le verrouillage est actif.');
  }
  $('#lock').classList.remove('hidden'); $('#lk').value = '';
}
async function unlock() {
  if (await sha((localStorage.soukassou_pin_salt || '') + $('#lk').value) == localStorage.soukassou_pin_hash) $('#lock').classList.add('hidden');
  else { alert('Code incorrect.'); $('#lk').value = ''; }
}
let idle; const bump = () => { clearTimeout(idle); if (localStorage.soukassou_pin_hash) idle = setTimeout(lock, LOCK_MS); };
['click','keydown','touchstart'].forEach(e => addEventListener(e, bump));

// ---------- Réseau, mise à jour, démarrage ----------
const net = () => { $('#net').className = 'w-2.5 h-2.5 rounded-full ' + (navigator.onLine ? 'bg-emerald-400' : 'bg-amber-400'); };
addEventListener('online', net); addEventListener('offline', net);
if ('serviceWorker' in navigator) {
  const had = navigator.serviceWorker.controller;
  navigator.serviceWorker.register('./sw.js');
  navigator.serviceWorker.addEventListener('controllerchange', () => { if (had) $('#upd').classList.remove('hidden'); });
}
(async () => {
  await DB.open(); net();
  if (navigator.storage && navigator.storage.persist) navigator.storage.persist();
  if (localStorage.soukassou_pin_hash) $('#lock').classList.remove('hidden');
  bump(); render();
})();
